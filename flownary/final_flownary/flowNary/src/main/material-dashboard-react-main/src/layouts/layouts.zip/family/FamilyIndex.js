import React, { useState } from "react";
import Tabs from '@mui/material/Tabs';
import Tab from '@mui/material/Tab';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import DashboardLayout from "examples/LayoutContainers/DashboardLayout";
import DashboardNavbar from "examples/Navbars/DashboardNavbar";
import Footer from "examples/Footer";
import { TextField, Avatar, ListItemText, Divider, List, ListItem, ListItemAvatar, Typography } from "@mui/material";

export default function Family() {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = (event) => {
    setSearchTerm(event.target.value);
  };

  const [value, setValue] = useState('one');

  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <DashboardLayout>
      <DashboardNavbar />

      <br />
      <Box sx={{ width: '100%', p: 4 }}>
        <div>
          <Typography id="modal-modal-title" variant="h6" component="div">
            패밀리
            <TextField
              sx={{ ml: 40, mb: 3 }}
              label="Search"
              variant="outlined"
              onChange={handleSearch}
            />
          </Typography>
        </div>
        <Tabs
          value={value}
          onChange={handleChange}
          textColor="secondary"
          indicatorColor="secondary"
          aria-label="secondary tabs example"
        >
          <Tab value="one" label="따름이" />
          <Tab value="two" label="따름이들" />
        </Tabs>
        <Typography id="modal-modal-description" sx={{ mt: 2 }}>
          {value === 'one' ? (
            <div>
              <List sx={{ width: '100%', maxWidth: 360 }}>
                <Divider variant="inset" component="li" />
                <ListItem alignItems="flex-start">
                  <ListItemAvatar>
                    <Avatar alt="Remy Sharp" src="/img/static/images/avatar/1.jpg" />
                  </ListItemAvatar>
                  <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                    <ListItemText
                      primary="아이디 혹은 닉네임"
                      secondary={
                        <React.Fragment>
                          <Typography
                            sx={{ display: 'inline' }}
                            component="span"
                            variant="body2"
                            color="text.primary"
                          >
                            닉네임 또는 실명
                          </Typography>
                        </React.Fragment>
                      }
                    />
                    <Button variant="contained" color="secondary" size="small" sx={{ ml: 2 }}>
                      팔로우 취소
                    </Button>
                    <Button variant="contained" color="primary" size="small" sx={{ ml: 1 }}>
                      메시지 보내기
                    </Button>
                  </Box>
                </ListItem>
                <Divider variant="inset" component="li" />
              </List>
            </div>
          ) : (
            <div>
              <List sx={{ width: '100%', maxWidth: 360 }}>
                <Divider variant="inset" component="li" />
                <ListItem alignItems="flex-start">
                  <ListItemAvatar>
                    <Avatar alt="John Doe" src="/img/static/images/avatar/2.jpg" />
                  </ListItemAvatar>
                  <Box sx={{ display: 'flex', alignItems: 'center', width: '100%' }}>
                    <ListItemText
                      primary="다른 아이디 혹은 닉네임"
                      secondary={
                        <React.Fragment>
                          <Typography
                            sx={{ display: 'inline' }}
                            component="span"
                            variant="body2"
                            color="text.primary"
                          >
                            다른 실명 혹은 메일주소
                          </Typography>
                        </React.Fragment>
                      }
                    />
                    <div style={{ marginleft: '150' }}>
                      <Button variant="contained" color="info" size="small" >
                        팔로우 취소
                      </Button>
                      <Button variant="contained" color="info" size="small" >
                        메시지 보내기
                      </Button>
                    </div>
                  </Box>
                </ListItem>
                <Divider variant="inset" component="li" />
              </List>
            </div>
          )}
        </Typography>
      </Box>
    </DashboardLayout>
  );
}
