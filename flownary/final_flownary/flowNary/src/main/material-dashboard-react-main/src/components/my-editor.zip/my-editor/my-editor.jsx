// src/components/my-editor/my-editor.jsx
import React, { useState } from 'react';
import { EditorState, AtomicBlockUtils, convertToRaw } from 'draft-js';
import { Editor } from 'react-draft-wysiwyg';
import 'react-draft-wysiwyg/dist/react-draft-wysiwyg.css';
import './my-editor.css';
import { uploadImage } from '../../api/cloudinary';
import Media from './media';
import { Button, Icon, Typography } from '@mui/material';
import draftToHtml from 'draftjs-to-html';
import './my-editor-switch'
import { styled, Switch } from '@mui/material';
import { useNavigate } from "react-router-dom";

export default function MyEditor() {
  const navigate = useNavigate();
  const [editorState, setEditorState] = useState(EditorState.createEmpty());

  const uploadImageCallBack = async (file) => {
    try {
      const url = await uploadImage(file);
      const contentState = editorState.getCurrentContent();
      const contentStateWithEntity = contentState.createEntity(
        'image', 'IMMUTABLE', { src: url }
      );
      const entityKey = contentStateWithEntity.getLastCreatedEntityKey();
      const newEditorState = AtomicBlockUtils.insertAtomicBlock(
        editorState, entityKey, ' '
      );
      const forcedEditorState = EditorState.forceSelection(
        newEditorState,
        newEditorState.getCurrentContent().getSelectionAfter()
      );
      setEditorState(forcedEditorState);
      return { data: { link: url } };
    } catch (error) {
      console.error('Image upload failed:', error);
      return { error: 'Image upload failed' };
    }
  };

  const myBlockRenderer = (contentBlock) => {
    const type = contentBlock.getType();
    if (type === 'atomic') {
      return {
        component: Media,
        editable: false,
      };
    }
  };

  const handleSave = () => {
    const contentState = editorState.getCurrentContent();
    const rawContentState = convertToRaw(contentState);
    const htmlContent = draftToHtml(rawContentState);
    console.log('Editor content in HTML format:', htmlContent);
    // 여기서 서버로 전송하거나 로컬 저장소에 저장할 수 있습니다.
  };

  // 스위치 스타일링
  const AntSwitch = styled(Switch)(({ theme }) => ({
    width: 28,
    height: 16,
    padding: 0,
    display: 'flex',
    '&:active': {
      '& .MuiSwitch-thumb': {
        width: 15,
      },
      '& .MuiSwitch-switchBase.Mui-checked': {
        transform: 'translateX(9px)',
      },
    },
    '& .MuiSwitch-switchBase': {
      padding: 2,
      '&.Mui-checked': {
        transform: 'translateX(12px)',
        color: '#fff',
        '& + .MuiSwitch-track': {
          opacity: 1,
          backgroundColor: theme.palette.mode === 'dark' ? '#177ddc' : '#1890ff',
        },
      },
    },
    '& .MuiSwitch-thumb': {
      boxShadow: '0 2px 4px 0 rgb(0 35 11 / 20%)',
      width: 12,
      height: 12,
      borderRadius: 6,
      transition: theme.transitions.create(['width'], {
        duration: 200,
      }),
    },
    '& .MuiSwitch-track': {
      borderRadius: 16 / 2,
      opacity: 1,
      backgroundColor:
        theme.palette.mode === 'dark' ? 'rgba(255,255,255,.35)' : 'rgba(0,0,0,.25)',
      boxSizing: 'border-box',
    },
  }));

  return (
    <div className="editor-container">
      <div className="editor-header">
        {/* 공개/비공개 설정 */}
        <Button component="label">
          <Typography sx={{ marginRight: '0.5em', fontSize: 'small', fontWeight: 'bold' }} style={{ color: 'black' }}>비공개</Typography>
          <AntSwitch sx={{ marginBottom: '0.3em' }} defaultChecked inputProps={{ 'aria-label': 'ant design' }} />
          <Typography sx={{ marginLeft: '0.5em', fontSize: 'small', fontWeight: 'bold' }} style={{ color: 'black' }}>공개</Typography>
        </Button>
        {/* 카카오 맵 API 지도 생성 */}
        <Button style={{ marginBottom: '0.1rem' }}>
          <Icon style={{ color: 'black', fontSize: 'large'}}>add_location_alt</Icon>
          <Typography fontSize='small' sx={{ color: 'gray', marginRight:'1rem' }}>위치 추가
          </Typography>
        </Button>
        <Button sx={{ color: 'lightcoral', marginLeft: '1em', marginBottom: '1rem', marginTop: '0.5rem' }} variant="contained" color="info" onClick={handleSave}>
          작성 완료
        </Button>
      </div >
      <Editor
        editorState={editorState}
        onEditorStateChange={setEditorState}
        blockRendererFn={myBlockRenderer}
        toolbar={{
          image: {
            uploadCallback: uploadImageCallBack,
            alt: { present: true, mandatory: true },
          },
        }}
        editorClassName='editor'
      />
    </div >
  );
}
